﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Employeedetails.Models;
using Employeedetails.ViewModel;
using Microsoft.EntityFrameworkCore;

namespace Employeedetails.Repository
{
    public class PostRepository : IPostRepository
    {
        EmployeeDBContext db;
        public PostRepository(EmployeeDBContext _db)
        {
            db = _db;
        }

        //Get Employee Details
        public async Task<List<EmployeeDetails>> GetEmployeeDet()
        {
            if (db != null)
            {
                return await db.EmployeeDetails.ToListAsync();
            }

            return null;
        }
               
        //Get Employee Details By Id
        public async Task<EmployeeViewModel> GetEmployeebyId(int? employeeId)
        {
            if (db != null)
            {
                 return await (from e in db.EmployeeDetails
                               where e.EmployeeId == employeeId
                              select new EmployeeViewModel
                              {
                                  EmployeeId = e.EmployeeId,
                                  EmployeeName = e.EmployeeName,
                                  Address = e.Address,
                                  Role = e.Role,
                                  Department = e.Department,
                                  SkillSets = e.SkillSets,
                                  Dob = e.Dob,
                                  Doj = e.Doj,
                                  IsActive = e.IsActive
                              }).FirstOrDefaultAsync();



            }

            return null;
        }

        //Add Employee details
        public async Task<long> AddEmployee(EmployeeDetails employeedet)
        {
            if (db != null)
            {
                await db.EmployeeDetails.AddAsync(employeedet);
                await db.SaveChangesAsync();

                return employeedet.EmployeeId;
            }

            return 0;
        }

        //Delete Employee Details By id
        public async Task<int> DeleteEmployee(int? employeeId)
        {
            int result = 0;

            if (db != null)
            {
                //Find the post for specific post id
                var emp = await db.EmployeeDetails.FirstOrDefaultAsync(x => x.EmployeeId == employeeId);

                if (emp != null)
                {
                    //Delete that post
                    db.EmployeeDetails.Remove(emp);

                    //Commit the transaction
                    result = await db.SaveChangesAsync();
                }
                return result;
            }

            return result;
        }

        //Update Employee details
        public async Task UpdateEmployee(EmployeeDetails employeedet)
        {
            if (db != null)
            {
                //Delete that post
                db.EmployeeDetails.Update(employeedet);

                //Commit the transaction
                await db.SaveChangesAsync();
            }
        }
    }
}
