﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Employeedetails.Models;
using Employeedetails.ViewModel;

namespace Employeedetails.Repository
{
    public interface IPostRepository
    {
        //Get Employee Details
        Task<List<EmployeeDetails>> GetEmployeeDet();

        //Task<List<EmployeeViewModel>> GetEmpDetailsByViewModel();

        //Get Employee Details By Id
        Task<EmployeeViewModel> GetEmployeebyId(int? employeeId);

        //Add Employee details
        Task<long> AddEmployee(EmployeeDetails employeedet);

        //Delete Employee Details By id
        Task<int> DeleteEmployee(int? employeeId);

        //Update Employee details
        Task UpdateEmployee(EmployeeDetails employeedet);
    }
}
