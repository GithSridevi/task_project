﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Employeedetails.Models;
using Employeedetails.Repository;

namespace Employeedetails.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
            IPostRepository postRepository;
            public EmployeeController(IPostRepository _postRepository)
            {
                postRepository = _postRepository;
            }

        #region Get Employee Details
        [HttpGet]
            [Route("GetEmployeeDet")]
            public async Task<IActionResult> GetEmployeeDet()
            {
                try
                {
                    var employees = await postRepository.GetEmployeeDet();
                    if (employees == null)
                    {
                        return NotFound();
                    }

                    return Ok(employees);
                }
                catch (Exception)
                {
                    return BadRequest();
                }

            }
        #endregion

        //[HttpGet]
        //[Route("GetEmpDetailsByViewModel")]
        //public async Task<IActionResult> GetEmpDetailsByViewModel()
        //{
        //    try
        //    {
        //        var empdetails = await postRepository.GetEmpDetailsByViewModel();
        //        if (empdetails == null)
        //        {
        //            return NotFound();
        //        }

        //        return Ok(empdetails);
        //    }
        //    catch (Exception)
        //    {
        //        return BadRequest();
        //    }
        //}

        #region Get Employee Details by Id
        [HttpGet]
            [Route("GetEmployeebyId")]
            public async Task<IActionResult> GetEmployeebyId(int? employeeId)
            {
                if (employeeId == null)
                {
                    return BadRequest();
                }

                try
                {
                    var emp = await postRepository.GetEmployeebyId(employeeId);

                    if (emp == null)
                    {
                        return NotFound();
                    }

                    return Ok(emp);
                }
                catch (Exception)
                {
                    return BadRequest();
                }
            }
        #endregion

        #region Add Employee Details
        [HttpPost]
            [Route("AddEmployee")]
            public async Task<IActionResult> AddEmployee([FromBody]EmployeeDetails model)
            {
                if (ModelState.IsValid)
                {
                    try
                    {
                        var empId = await postRepository.AddEmployee(model);
                        if (empId > 0)
                        {
                            return Ok(empId);
                        }
                        else
                        {
                            return NotFound();
                        }
                    }
                    catch (Exception)
                    {

                        return BadRequest();
                    }

                }

                return BadRequest();
            }
        #endregion

        #region Delete Employee Details
        [HttpDelete]
            [Route("DeleteEmployee")]
            public async Task<IActionResult> DeleteEmployee(int? empId)
            {
                int result = 0;

                if (empId == null)
                {
                    return BadRequest();
                }

                try
                {
                    result = await postRepository.DeleteEmployee(empId);
                    if (result == 0)
                    {
                        return NotFound();
                    }
                    return Ok();
                }
                catch (Exception)
                {

                    return BadRequest();
                }
            }
        #endregion

        #region Update Employee Details 
        [HttpPut]
            [Route("UpdateEmployee")]
            public async Task<IActionResult> UpdateEmployee([FromBody]EmployeeDetails model)
            {
                if (ModelState.IsValid)
                {
                    try
                    {
                        await postRepository.UpdateEmployee(model);

                        return Ok();
                    }
                    catch (Exception ex)
                    {
                        if (ex.GetType().FullName ==
                                 "Microsoft.EntityFrameworkCore.DbUpdateConcurrencyException")
                        {
                            return NotFound();
                        }

                        return BadRequest();
                    }
                }

                return BadRequest();
            }
        #endregion

        #region Refernce Blocks
        //// GET: api/Employee
        //[HttpGet]
        //public IEnumerable<string> Get()
        //{
        //    return new string[] { "value1", "value2" };
        //}

        //// GET: api/Employee/5
        //[HttpGet("{id}", Name = "Get")]
        //public string Get(int id)
        //{
        //    return "value";
        //}

        //// POST: api/Employee
        //[HttpPost]
        //public void Post([FromBody] string value)
        //{
        //}

        //// PUT: api/Employee/5
        //[HttpPut("{id}")]
        //public void Put(int id, [FromBody] string value)
        //{
        //}

        //// DELETE: api/ApiWithActions/5
        //[HttpDelete("{id}")]
        //public void Delete(int id)
        //{
        //}
        #endregion
    }
}
