﻿using System;
using System.Collections.Generic;

namespace Employeedetails.Models
{
    public partial class EmployeeDetails
    {
        public long EmployeeId { get; set; }
        public string EmployeeName { get; set; }
        public string Address { get; set; }
        public string Role { get; set; }
        public string Department { get; set; }
        public string SkillSets { get; set; }
        public DateTime Dob { get; set; }
        public DateTime Doj { get; set; }
        public bool? IsActive { get; set; }
    }
}
